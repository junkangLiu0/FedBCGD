# Stock Price Prediction with LSTM and Trading Reinforcement Learning base on TensorFlow

## Overview
In this code, we do stock price prediction with LSTM and trading with reinforcement learning on our own data.

## Experiment Result
                                                            China
![image1](./image/china.png)

                                                         Comparison
![image2](./image/five.png)

                                                   Portfolio Performance 1
![image3](./image/graph1.png)

                                                   Portfolio Performance 2
![image4](./image/graph2.png)
